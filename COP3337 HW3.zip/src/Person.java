/**
 * The Person class represents an individual with a name.
 * This is the base class that can be extended by other classes to include additional attributes.
 */
public class Person {
    private String name;

    /**
     * Default constructor for the Person class.
     * Initializes the object with a default name of "No name given".
     */
    public Person() {
        this("No name given");
    }
    /**
     * Parameterized constructor for the Person class.
     * Initializes the object with a specific name.
     *
     * @param name The name of the person.
     * @throws IllegalArgumentException if the name is null.
     */
    public Person(String name) {
        setName(name);
    }

    /**
     * Copy constructor for the Person class.
     * Initializes the object by copying another Person object.
     *
     * @param object The Person object to be copied.
     */
    public Person(Person object) {
        this(object.getName());
    }

    /**
     * Retrieves the name of the person.
     *
     * @return The name of the person.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the person.
     * Throws an IllegalArgumentException if the name is null.
     *
     * @param name The name to be set.
     * @throws IllegalArgumentException if the name is null.
     */
    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null");
        }
        this.name = name;
    }

    /**
     * Returns a string representation of the person, including their name.
     *
     * @return A string representing the person's details.
     */
    @Override
    public String toString() {
        return "The doctor " + name;
    }

    /**
     * Checks if two Person objects are equal based on their names.
     *
     * @param object The Person object to be compared.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(Person object) {
        return getName().equals(object.getName());
    }
}
