/**
 * The Patient class represents a patient in a medical system.
 * It extends the Person class and inherits the name attribute.
 */
public class Patient extends Person {

    /**
     * Default constructor for the Patient class.
     * Initializes the patient with the default name of "No name given".
     */
    public Patient() {
        this("No name given");
    }

    /**
     * Parameterized constructor for the Patient class.
     * Initializes the patient with a specific name.
     *
     * @param name The name of the patient.
     */
    public Patient(String name) {
        super(name);
    }

    /**
     * Copy constructor for the Patient class.
     * Initializes the patient by copying another Patient object.
     *
     * @param object The Patient object to be copied.
     */
    public Patient(Patient object) {
        super(object);
    }

    /**
     * Returns a string representation of the patient, including their name.
     * The output format includes the patient's name and a placeholder for their primary doctor.
     *
     * @return A string representing the patient's details.
     */
    @Override
    public String toString() {
        return "The name is: " + getName() + ", Primary doctor is: ";
    }

    /**
     * Checks if two Patient objects are equal based on their names.
     *
     * @param object The Patient object to be compared.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(Patient object) {
        return getName().equals(object.getName());
    }
}
