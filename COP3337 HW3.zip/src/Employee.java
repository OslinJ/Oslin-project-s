import java.util.Date;

/**
 * The Employee class represents a person who is employed by a company.
 * It extends the Person class and adds a hire date field.
 */
public class Employee extends Person {
    private Date hireDate;

    /**
     * Default constructor for the Employee class.
     * Initializes the object with default values for name and hire date.
     */
    public Employee() {
        this(new Date(), "No name given");
    }

    /**
     * Parameterized constructor for the Employee class.
     * Initializes the object with specific values for hire date and name.
     *
     * @param hireDate The hire date of the employee.
     * @param name     The name of the employee.
     * @throws IllegalArgumentException if the hire date is null.
     */
    public Employee(Date hireDate, String name) {
        super(name);
        setHireDate(hireDate);
    }

    /**
     * Copy constructor for the Employee class.
     * Initializes the object by copying another Employee object.
     *
     * @param object The Employee object to be copied.
     */
    public Employee(Employee object) {
        super(object);
        setHireDate(object.getHireDate());
    }

    /**
     * Retrieves the hire date of the employee.
     *
     * @return The hire date of the employee.
     */
    public Date getHireDate() {
        return hireDate;
    }

    /**
     * Sets the hire date of the employee.
     * Throws an IllegalArgumentException if the hire date is null.
     *
     * @param hireDate The hire date to be set.
     * @throws IllegalArgumentException if the hire date is null.
     */
    public void setHireDate(Date hireDate) {
        if (hireDate == null) {
            throw new IllegalArgumentException("Hire date cannot be null");
        }
        this.hireDate = hireDate;
    }

    /**
     * Returns a string representation of the employee, including their name and hire date.
     *
     * @return A string representing the employee's details.
     */
    @Override
    public String toString() {
        return super.toString() + " was hired on " + getHireDate();
    }

    public boolean equals(Employee object) {
        return super.equals(object) && getHireDate().equals(object.getHireDate());
    }
}
