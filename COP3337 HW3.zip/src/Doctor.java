import java.util.Date;
public class Doctor extends SalariedEmployee {
    private String specialty;
    private double visitFee;

    /**
     * Default constructor for the Doctor class.
     * Initializes the object with default values for name, hire date, salary, specialty, and visit fee.
     */
    public Doctor() {
        this("No name given", new Date(), 0.0, "No specialty given", 0.0);
    }

    /**
     * Parameterized constructor for the Doctor class.
     * Initializes the object with specific values for name, hire date, salary, specialty, and visit fee.
     *
     * @param name      The name of the doctor.
     * @param hireDate  The hire date of the doctor.
     * @param salary    The salary of the doctor.
     * @param specialty The doctor's medical specialty.
     * @param visitFee  The fee for a patient visit.
     * @throws IllegalArgumentException if specialty is null or visit fee is less than zero.
     */
    public Doctor(String name, Date hireDate, double salary, String specialty, double visitFee) {
        super(name, hireDate, salary);
        setSpecialty(specialty);
        setVisitFee(visitFee);
    }

    /**
     * Copy constructor for the Doctor class.
     * Initializes the object by copying another Doctor object.
     *
     * @param object The Doctor object to be copied.
     */
    public Doctor(Doctor object) {
        super(object);
        setSpecialty(object.getSpecialty());
        setVisitFee(object.getVisitFee());
    }

    /**
     * Retrieves the doctor's specialty.
     *
     * @return The doctor's medical specialty.
     */
    public String getSpecialty() {
        return specialty;
    }

    /**
     * Sets the doctor's specialty.
     * Throws an IllegalArgumentException if the specialty is null.
     *
     * @param specialty The medical specialty to be set.
     * @throws IllegalArgumentException if the specialty is null.
     */
    public void setSpecialty(String specialty) {
        if (specialty == null) {
            throw new IllegalArgumentException("Specialty cannot be null");
        }
        this.specialty = specialty;
    }

    /**
     * Retrieves the doctor's visit fee.
     *
     * @return The fee for a patient visit.
     */
    public double getVisitFee() {
        return visitFee;
    }

    /**
     * Sets the doctor's visit fee.
     * Throws an IllegalArgumentException if the visit fee is less than zero.
     *
     * @param visitFee The visit fee to be set.
     * @throws IllegalArgumentException if the visit fee is less than zero.
     */
    public void setVisitFee(double visitFee) {
        if (visitFee < 0.0) {
            throw new IllegalArgumentException("Visit fee cannot be less than zero");
        }
        this.visitFee = visitFee;
    }

    /**
     * Returns a string representation of the doctor, including their name, salary, specialty, and visit fee.
     *
     * @return A string representing the doctor's details.
     */
    @Override
    public String toString() {
        return super.toString() + "\nThe specialty is " + getSpecialty() + " and visit fee is $" + getVisitFee();
    }

    /**
     * Checks if two Doctor objects are equal based on their name, salary, specialty, and visit fee.
     *
     * @param object The Doctor object to be compared.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(Doctor object) {
        return super.equals(object) &&
                getSpecialty().equals(object.getSpecialty()) &&
                getVisitFee() == object.getVisitFee();
    }
}
