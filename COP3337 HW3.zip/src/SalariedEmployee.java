import java.util.Date;

/**
 * The SalariedEmployee class represents an employee who is paid a fixed salary.
 * This class extends the Employee class and adds a salary field.
 */
public class SalariedEmployee extends Employee {
    private double salary;

    /**
     * Default constructor for the SalariedEmployee class.
     * Initializes the object with default values for name, hire date, and salary.
     */
    public SalariedEmployee() {
        this("No name given", new Date(), 0.0);
    }

    /**
     * Parameterized constructor for the SalariedEmployee class.
     * Initializes the object with specific values for name, hire date, and salary.
     *
     * @param name     The name of the employee.
     * @param hireDate The hire date of the employee.
     * @param salary   The salary of the employee.
     * @throws IllegalArgumentException if the salary is less than zero.
     */
    public SalariedEmployee(String name, Date hireDate, double salary) {
        super(hireDate, name);
        setSalary(salary);
    }

    /**
     * Copy constructor for the SalariedEmployee class.
     * Initializes the object by copying another SalariedEmployee object.
     *
     * @param object The SalariedEmployee object to be copied.
     */
    public SalariedEmployee(SalariedEmployee object) {
        super(object);
        setSalary(object.getSalary());
    }

    /**
     * Retrieves the salary of the employee.
     *
     * @return The employee's salary.
     */
    public double getSalary() {
        return salary;
    }

    /**
     * Sets the salary of the employee.
     * Throws an IllegalArgumentException if the salary is less than zero.
     *
     * @param salary The salary to be set.
     * @throws IllegalArgumentException if the salary is less than zero.
     */
    public void setSalary(double salary) {
        if (salary < 0.0) {
            throw new IllegalArgumentException("Salary cannot be less than zero");
        }
        this.salary = salary;
    }

    /**
     * Returns a string representation of the salaried employee, including
     * their name, hire date, and salary.
     *
     * @return A string representing the employee details.
     */
    @Override
    public String toString() {
        return super.toString() + " at Salary " + getSalary();
    }

    /**
     * Checks if two SalariedEmployee objects are equal based on their name, hire date, and salary.
     *
     * @param object The SalariedEmployee object to be compared.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(SalariedEmployee object) {
        return super.equals(object) && getSalary() == object.getSalary();
    }
}
