import java.util.ArrayList;

/**
 * The Billing class represents a billing record that holds information about
 * a patient, a doctor, and the fees due for medical services.
 */
public class Billing {
    private Patient patient;
    private Doctor doctor;
    private double feesDue;

    /**
     * Default constructor for the Billing class.
     * Initializes with default values for patient, doctor, and fees.
     */
    public Billing() {
        this(new Patient(), new Doctor(), 0.0);
    }

    /**
     * Parameterized constructor that initializes a Billing object with specific values for patient, doctor, and fees due.
     *
     * @param patient The patient associated with the billing record.
     * @param doctor  The doctor providing the medical services.
     * @param feesDue The amount of fees due for the services.
     * @throws IllegalArgumentException if the feesDue is less than zero.
     */
    public Billing(Patient patient, Doctor doctor, double feesDue) {
        this.patient = patient;
        this.doctor = doctor;
        setFeesDue(feesDue);
    }

    /**
     * Copy constructor. Creates a Billing object by copying another Billing object.
     *
     * @param object The Billing object to be copied.
     */
    public Billing(Billing object) {
        this(object.getPatient(), object.getDoctor(), object.getFeesDue());
    }

    /**
     * Retrieves the patient associated with this billing record.
     *
     * @return The patient object.
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     * Sets the patient associated with this billing record.
     *
     * @param patient The patient to be set.
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    /**
     * Retrieves the doctor associated with this billing record.
     *
     * @return The doctor object.
     */
    public Doctor getDoctor() {
        return doctor;
    }

    /**
     * Sets the doctor associated with this billing record.
     *
     * @param doctor The doctor to be set.
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    /**
     * Sets the amount of fees due for the billing record.
     * Throws an IllegalArgumentException if the value is less than zero.
     *
     * @param feesDue The fees to be set.
     * @throws IllegalArgumentException if feesDue is less than zero.
     */
    public void setFeesDue(double feesDue) {
        if (feesDue < 0.0) {
            throw new IllegalArgumentException("Fees due cannot be less than zero");
        }
        this.feesDue = feesDue;
    }

    /**
     * Retrieves the amount of fees due for the billing record.
     *
     * @return The fees due.
     */
    public double getFeesDue() {
        return feesDue;
    }

    /**
     * Returns a string representation of the billing record.
     *
     * @return A string containing the patient name, doctor name, and fees due.
     */
    @Override
    public String toString() {
        return "Patient: " + patient.getName() + "\nDoctor: " + doctor.getName() + "\nAmount due: $" + getFeesDue();
    }

    /**
     * Checks if two Billing objects are equal based on their patient, doctor, and fees due.
     *
     * @param obj The object to be compared.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Billing billing = (Billing) obj;
        return Double.compare(billing.getFeesDue(), getFeesDue()) == 0 &&
                patient.equals(billing.patient) &&
                doctor.equals(billing.doctor);
    }

    /**
     * Calculates the total amount of fees from a list of Billing records.
     *
     * @param billings The list of Billing records.
     * @return The total amount of fees.
     */
    public static double totalBill(ArrayList<Billing> billings) {
        double total = 0.0;
        for (Billing billing : billings) {
            total += billing.getFeesDue();
        }
        return total;
    }
}
