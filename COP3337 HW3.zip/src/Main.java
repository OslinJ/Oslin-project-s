import java.util.ArrayList;
import java.util.Date;

/**
 * The Main class demonstrates the creation of Doctor, Patient, and Billing objects
 * and calculates the total income from billing records.
 */
public class Main {
    /**
     * creates Doctor, Patient, and Billing objects and prints relevant information.
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {

        // Creating Doctor objects
        Doctor doctor = new Doctor("Bob", new Date(69), 34000.0, "Pediatrician", 10.5);
        Doctor doctor2 = new Doctor("Susan", new Date(69), 450000.0, "Surgeon", 150.5);
        Doctor doctor3 = new Doctor("Lilly", new Date(69), 290000.0, "Kidney", 95.5);

        // Printing Doctor information
        System.out.println(doctor);
        System.out.println(doctor2);
        System.out.println(doctor3);

        // Creating Patient objects
        Patient patient = new Patient("Fred");
        Patient patient2 = new Patient("Sally");
        Patient patient3 = new Patient("John");

        // Printing Patient and associated Doctor information
        System.out.println("\n*Patient's Information*");
        System.out.println(patient + doctor.getName());
        System.out.println(patient2 + doctor2.getName());
        System.out.println(patient3 + doctor3.getName());

        // Creating Billing records
        System.out.println("\n*Billing's Information*");
        Billing billing = new Billing(patient, doctor, 21.0);
        Billing billing2 = new Billing(patient2, doctor2, 150.5);
        Billing billing3 = new Billing(patient3, doctor3, 170.0);

        // Adding Billing records to a list
        ArrayList<Billing> billings = new ArrayList<>();
        billings.add(billing);
        billings.add(billing2);
        billings.add(billing3);

        // Printing Billing information
        System.out.println(billing);
        System.out.println(billing2);
        System.out.println(billing3);

        // Calculating and printing total income from all billing records
        double total = Billing.totalBill(billings);
        System.out.println("\nThe total income from billing records is " + total);
    }
}
