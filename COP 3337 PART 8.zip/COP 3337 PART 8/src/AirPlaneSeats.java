import java.util.Scanner;
/**
 * A simple console-based airplane seat reservation system.
 * Users can select seats by specifying the row and column, view the seating arrangement,
 * and exit the application.
 */
public class AirPlaneSeats {
    private int seatRow;
    private char seatCol;
    private char[][] seatsAvailable;
    /**
     * Constructs an AirPlaneSeats object, initializes the seat map, displays the seat layout,
     * and starts the seat selection process.
     */
    public AirPlaneSeats() {
        System.out.println("You will be selecting seats for this airplane");
        seatsAvailable = new char[][]{
                {'1', 'A', 'B', 'C', 'D'},
                {'2', 'A', 'B', 'C', 'D'},
                {'3', 'A', 'B', 'C', 'D'},
                {'4', 'A', 'B', 'C', 'D'},
                {'5', 'A', 'B', 'C', 'D'},
                {'6', 'A', 'B', 'C', 'D'},
                {'7', 'A', 'B', 'C', 'D'}
        };

        displaySeats();
        selectSeat();
    }

    /**
     * Displays the current seating arrangement to the console.
     * The seat map is printed in a grid format, showing available seats and their status.
     */
    public void displaySeats() {
        for (char[] chars : seatsAvailable) {
            for (char aChar : chars) {
                System.out.print(aChar + " ");
            }
            System.out.println();
        }
    }

    /**
     * Handles the seat selection process.
     * Prompts the user to enter seat selection in the format 'RowLetter' (e.g., 3B) or 'Q' to quit.
     * Validates the input, updates the seat map, and displays the updated seating arrangement.
     */
    public void selectSeat() {
        Scanner scan = new Scanner(System.in);

        while (true) {
            System.out.println("You will input the seat selection using the row number and then the seat letter (ex - 3B)");
            System.out.println("Please enter the seat number or 'Q' to quit");
            String input = scan.next();

            if (input.equalsIgnoreCase("Q")) {
                System.out.println("You are exiting the AirPlane...");
                break;
            }

            seatRow = Integer.parseInt(input.substring(0, 1));
            seatCol = input.charAt(input.length() - 1);
            seatCol = Character.toUpperCase(seatCol);

            if (seatRow < 1 || seatRow > 7 || seatCol < 'A' || seatCol > 'D') {
                System.out.println("The seat entered is located in a different airplane");
                continue;
            }

            int row = seatRow - 1;
            int col = seatCol - 'A' + 1;
            if (seatsAvailable[row][col] == 'X') {
                System.out.println("The seat is already taken, try another seat");
                continue;
            }
            seatsAvailable[row][col] = 'X';
            displaySeats();
        }
        scan.close();
    }
    /**
     * The entry point of the application. Creates an instance of AirPlaneSeats to start the application.
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        new AirPlaneSeats();
    }
}
